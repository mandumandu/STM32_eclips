#include "hw_def.h"


void timerInit(void);


void timerSetISR(uint8_t ch, void (*func)(), uint32_t time_us);
void timerStart(uint8_t ch);
