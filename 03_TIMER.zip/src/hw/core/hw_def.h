#include "def.h"
#include "bsp.h"


#define _HW_DEF_LED_USER1   _DEF_LED1
#define _HW_DEF_LED_USER2   _DEF_LED2
#define _HW_DEF_LED_USER3   _DEF_LED3
#define _HW_DEF_LED_USER4   _DEF_LED4

#define _HW_DEF_BUTTON_USER1 _DEF_BUTTON1
#define _HW_DEF_BUTTON_USER2 _DEF_BUTTON2
