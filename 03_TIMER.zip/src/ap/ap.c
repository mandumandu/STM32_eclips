#include "ap.h"


void timerISR(void)
{
  static uint32_t cnt = 0;


  if (cnt%100 == 0)
  {
    ledToggle(_HW_DEF_LED_USER2);
  }

  cnt++;
}





void apInit(void)
{
  timerSetISR(_DEF_TIMER1, timerISR, 1000); // 1000us Timer Interrupt
  timerStart(_DEF_TIMER1);
}

void apMain(void)
{
  while(1)
  {
    ledToggle(_HW_DEF_LED_USER1);
    delay(1000);
  }
}
