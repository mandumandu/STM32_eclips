#include "hw_def.h"


void buttonInit(void);

bool buttonGetPressed(uint8_t ch);
