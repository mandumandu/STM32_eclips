#include "ap.h"



bool runEraseFlash(void);
bool runShowFlash(void);
bool runVerifyEmpty(void);
bool runTestWrite(void);



void apInit(void)
{

}

void apMain(void)
{

  while(1)
  {
    if (vcpAvailable() > 0)
    {
      uint8_t ch;

      ch = vcpRead();

      if (ch == 'h')
      {
        vcpPrintf("h.. help\n");
        vcpPrintf("e.. erase flash\n");
        vcpPrintf("t.. test write\n");
        vcpPrintf("s.. show flash\n");
        vcpPrintf("v.. verify empty\n");
        vcpPrintf("\n");
      }

      if (ch == 'e')
      {
        runEraseFlash();
      }
      if (ch == 's')
      {
        runShowFlash();
      }
      if (ch == 'v')
      {
        runVerifyEmpty();
      }
      if (ch == 't')
      {
        runTestWrite();
      }
    }
  }
}

bool runEraseFlash(void)
{
  bool ret = true;


  vcpPrintf("EraseFlash..");
  if (flashErase(0x8040000, 256*1024) == true)
  {
    vcpPrintf("OK\n");
  }
  else
  {
    vcpPrintf("Fail\n");
    ret = false;
  }

  return ret;
}

bool runShowFlash(void)
{
  bool ret = true;
  uint32_t *p_flash = (uint32_t *)0x8040000;


  vcpPrintf("ShowFlash..\n");

  for (int i=0; i<8; i++)
  {
    vcpPrintf("0x%08X : 0x%08X \n", (int)&p_flash[i], p_flash[i]);
  }

  return ret;
}

bool runVerifyEmpty(void)
{
  bool ret = true;
  volatile uint32_t *p_flash = (uint32_t *)0x8040000;


  vcpPrintf("VerifyEmpty..");

  for (int i=0; i<256*1024/4; i++)
  {
    if (p_flash[i] != 0xFFFFFFFF)
    {
      ret = false;
      break;
    }
  }

  if (ret == true)
  {
    vcpPrintf("OK\n");
  }
  else
  {
    vcpPrintf("Fail\n");
  }

  return ret;
}

bool runTestWrite(void)
{
  bool ret = true;
  uint32_t *p_flash = (uint32_t *)0x8040000;


  vcpPrintf("TestWrite..");

  for (uint32_t i=0; i<8; i++)
  {
    ret = flashWrite((uint32_t)&p_flash[i], (uint8_t *)&i, 4);

    if (ret == false)
    {
      break;
    }
  }

  if (ret == true)
  {
    vcpPrintf("OK\n");
  }
  else
  {
    vcpPrintf("Fail\n");
  }

  return ret;
}
