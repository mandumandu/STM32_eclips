#include "ap.h"


void apInit(void)
{

}

void apMain(void)
{
  while(1)
  {
    if (vcpAvailable() > 0)
    {
      vcpPrintf("vcp rx : 0x%X\n", vcpRead());
    }
  }
}
