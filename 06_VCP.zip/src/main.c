#include "main.h"


int main(void)
{
  hwInit();
  apInit();

  apMain();
}
