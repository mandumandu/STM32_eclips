#include "hw_def.h"


#include "core/led.h"
#include "core/button.h"
#include "core/timer.h"
#include "core/pwm.h"


#include "usb_cdc/usb.h"
#include "usb_cdc/vcp.h"

void hwInit(void);


void delay(uint32_t time_ms);
uint32_t millis(void);
