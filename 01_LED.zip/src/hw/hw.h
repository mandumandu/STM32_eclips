#include "hw_def.h"


#include "core/led.h"
#include "core/button.h"

void hwInit(void);


void delay(uint32_t time_ms);
uint32_t millis(void);
