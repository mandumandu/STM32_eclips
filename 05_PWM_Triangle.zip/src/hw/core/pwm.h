#include "hw_def.h"


void pwmInit(void);


void pwmWrite(uint8_t ch, uint8_t pwm_data);
