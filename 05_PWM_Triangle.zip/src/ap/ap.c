#include "ap.h"




void apInit(void)
{

}

void apMain(void)
{
  uint16_t i1 = 0;
  uint16_t i2 = 0;
  uint8_t pwm_out = 0;


  while(1)
  {
    for(i1 = 0 ; i1==5000 ; i1++ )
    {
      pwmWrite(_DEF_PWM1, pwm_out);
      pwm_out += 10;
      delay(50);
    }

    for(i2 = 0 ; i2==5000 ; i2++ )
    {
      pwmWrite(_DEF_PWM1, pwm_out);
      pwm_out-= 10;
      delay(50);
    }
  }
}
