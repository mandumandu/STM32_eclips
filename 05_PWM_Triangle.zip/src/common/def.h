#include <stdint.h>
#include <stdbool.h>


#define _DEF_LED1     0
#define _DEF_LED2     1
#define _DEF_LED3     2
#define _DEF_LED4     3


#define _DEF_BUTTON1  0
#define _DEF_BUTTON2  1

#define _DEF_PWM1       0
