#include "hw_def.h"


#include "core/led.h"


void hwInit(void);


void delay(uint32_t time_ms);
uint32_t millis(void);
