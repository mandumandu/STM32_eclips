#include "ap.h"




void apInit(void)
{

}

void apMain(void)
{
  uint8_t pwm_out = 0;


  while(1)
  {
    pwmWrite(_DEF_PWM1, pwm_out);
    pwm_out += 10;
    delay(50);
  }
}
